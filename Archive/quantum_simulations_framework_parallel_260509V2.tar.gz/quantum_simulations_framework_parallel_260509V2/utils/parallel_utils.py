"""Utilities for parallel processing with memory constraints."""
import multiprocessing
import os


def get_safe_n_jobs(memory_per_job_gb: float) -> int:
    """
    Calculate safe number of parallel jobs based on available memory.
    
    Parameters
    ----------
    memory_per_job_gb : float
        Estimated memory requirement per job in GB
    
    Returns
    -------
    int
        Number of parallel jobs to use
    """
    try:
        import psutil
        available_memory_gb = psutil.virtual_memory().available / (1024**3)
        memory_limited_jobs = max(1, int(available_memory_gb * 0.66 / memory_per_job_gb))
    except ImportError:
        memory_limited_jobs = multiprocessing.cpu_count()
    
    cpu_count = multiprocessing.cpu_count()
    cpu_limited_jobs = max(1, int(cpu_count * 0.66))
    
    return min(memory_limited_jobs, cpu_limited_jobs)
