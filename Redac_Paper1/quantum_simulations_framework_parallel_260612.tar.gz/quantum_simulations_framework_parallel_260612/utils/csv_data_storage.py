"""
Reproducible Data Storage and Provenance Tracking.

This module provides the CSVDataStorage class, designed to manage simulation
outputs with high numerical precision and comprehensive metadata. It implements
schema validation and SHA-256 configuration hashing to ensure that all
results are fully traceable back to their simulation parameters and git state.
"""

import logging
import os
from datetime import datetime
from typing import Any, Dict

import numpy as np
import pandas as pd

logger = logging.getLogger(__name__)


class CSVDataStorage:
    """
    Manager for structured data persistence and provenance tracking.

    This class enforces strict schema validation for simulation outputs and
    automatically attaches metadata (git SHA, configuration hash, timestamps)
    to saved files. It ensures that data remains portable and identifiable
    throughout the research lifecycle.

    Attributes
    ----------
    REQUIRED_COLUMNS : set
        Columns that must be present in a quantum dynamics DataFrame for
        validation to pass (e.g., 'time_fs', 'coherences').
    """

    REQUIRED_COLUMNS = {"time_fs", "coherences"}

    def __init__(self, output_dir: str = "../simulation_data/"):
        """
        Initialize CSV data storage.

        Parameters:
        -----------
        output_dir : str
            Directory to store CSV files
        """
        self.output_dir = output_dir
        os.makedirs(output_dir, exist_ok=True)
        logger.info(f"CSV data storage initialized at {output_dir}")

    def validate_schema(
        self, df: pd.DataFrame, schema_type: str = "quantum_dynamics"
    ) -> bool:
        """
        Validate DataFrame schema against expected columns and types.

        Parameters
        ----------
        df : pd.DataFrame
            DataFrame to validate
        schema_type : str
            Type of schema to validate against

        Returns
        -------
        bool
            True if schema is valid
        """
        if schema_type == "quantum_dynamics":
            missing = self.REQUIRED_COLUMNS - set(df.columns)
            if missing:
                raise ValueError(f"Missing required columns: {missing}")
            if df[list(self.REQUIRED_COLUMNS)].isna().any().any():
                raise ValueError("Required columns contain NaN values")
            logger.info(f"Schema validation passed for {schema_type}")
            return True
        return True

    def save_quantum_dynamics_results(
        self,
        time_points: np.ndarray,
        populations: np.ndarray,
        coherences: np.ndarray,
        quantum_metrics: Dict[str, np.ndarray],
        filename_prefix: str = "quantum_dynamics",
        config_dict: Dict[str, Any] = None,
        **metadata,
    ) -> str:
        """
        Save quantum dynamics results with strict provenance and high precision.

        FIX H-6: config_dict is serialised with a numpy-aware JSON encoder so
        that np.float64 / np.ndarray values (common after yaml.safe_load +
        numpy processing) do not raise TypeError.

        FIX H-7: the redundant os.makedirs(os.path.dirname(filepath)) call is
        removed — the directory is guaranteed to exist from __init__, and
        os.path.dirname returns '' when output_dir has no subdirectory component,
        which would cause os.makedirs to raise FileNotFoundError.

        FIX M-4: filename_prefix is sanitised with os.path.basename to prevent
        path-traversal if a caller passes a prefix containing '../'.
        """
        import hashlib
        import json
        import subprocess

        class _NumpyEncoder(json.JSONEncoder):
            """JSON encoder that handles numpy scalars and arrays."""

            def default(self, obj):
                if isinstance(obj, np.ndarray):
                    return obj.tolist()
                if isinstance(obj, (np.integer,)):
                    return int(obj)
                if isinstance(obj, (np.floating,)):
                    return float(obj)
                return super().default(obj)

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

        # FIX M-4: sanitise prefix to prevent path traversal
        safe_prefix = os.path.basename(filename_prefix) or "quantum_dynamics"

        # Calculate Configuration Hash for Provenance
        config_hash = "no_config"
        if config_dict is not None:  # use 'is not None' — empty dict is valid
            # FIX H-6: use _NumpyEncoder to handle numpy types in config_dict
            config_str = json.dumps(config_dict, sort_keys=True, cls=_NumpyEncoder)
            config_hash = hashlib.sha256(config_str.encode()).hexdigest()[:12]
            metadata["config_sha256"] = config_hash
            metadata["provenance"] = "Hardened_JPCL_Resubmission_v1.3"

        try:
            git_sha = (
                subprocess.check_output(
                    ["git", "rev-parse", "HEAD"],
                    cwd=os.path.dirname(os.path.dirname(os.path.dirname(__file__))),
                    stderr=subprocess.DEVNULL,
                )
                .decode()
                .strip()[:12]
            )
            metadata["git_commit_sha"] = git_sha
        except (subprocess.CalledProcessError, FileNotFoundError):
            metadata["git_commit_sha"] = "unknown"

        # FIX H-7: output_dir is already created in __init__; do not call
        # os.makedirs(os.path.dirname(filepath)) here — dirname returns '' when
        # output_dir is a bare name, causing FileNotFoundError.
        filepath = os.path.join(
            self.output_dir, f"{safe_prefix}_{config_hash}_{timestamp}.csv"
        )

        # Create DataFrame with time series data
        data_dict = {"time_fs": time_points}

        # Add populations for each site
        n_sites = populations.shape[1] if len(populations.shape) > 1 else 1
        if n_sites > 1:
            for i in range(n_sites):
                data_dict[f"population_site_{i + 1}"] = populations[:, i]
        else:
            data_dict["populations"] = populations

        data_dict["coherences"] = coherences
        for metric_name, metric_values in quantum_metrics.items():
            if isinstance(metric_values, np.ndarray) and len(metric_values) == len(
                time_points
            ):
                data_dict[metric_name] = metric_values
            elif isinstance(metric_values, np.ndarray):
                # Truncate or pad to match time_points length
                n = len(time_points)
                if len(metric_values) >= n:
                    data_dict[metric_name] = metric_values[:n]
                else:
                    padded = np.full(n, np.nan)
                    padded[: len(metric_values)] = metric_values
                    data_dict[metric_name] = padded
            else:
                data_dict[metric_name] = [metric_values] * len(time_points)

        df = pd.DataFrame(data_dict)

        # Validate schema before saving
        try:
            self.validate_schema(df, schema_type="quantum_dynamics")
        except ValueError as e:
            logger.error(f"Schema validation failed: {e}")
            raise

        # High-Precision Scientific Formatting (Reviewer 1 Compliance)
        df.to_csv(filepath, index=False, float_format="%.10e")

        # Append Metadata as Comments to maintain CSV structure but ensure provenance
        with open(filepath, "a") as f:
            f.write(f"\n# METADATA: {json.dumps(metadata)}\n")

        logger.info(
            f"Hardened results saved with SHA-256 [{config_hash}] at {filepath}"
        )
        return filepath

    def save_spectral_optimization(
        self,
        optimization_results: Dict[str, Any],
        filename_prefix: str = "spectral_optimization",
        **metadata,
    ) -> str:
        """
        Save spectral optimization results to CSV.

        Parameters:
        -----------
        optimization_results : dict
            Results from spectral optimization
        filename_prefix : str
            Prefix for the output filename
        **metadata : dict
            Additional metadata to include

        Returns:
        --------
        str
            Path to the saved CSV file
        """
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filepath = os.path.join(self.output_dir, f"{filename_prefix}_{timestamp}.csv")

        # Flatten the optimization results into a DataFrame
        data_dict = {}

        # Add parameters
        if "optimal_params" in optimization_results:
            for i, param in enumerate(optimization_results["optimal_params"]):
                data_dict[f"param_{i + 1}"] = [param]

        # Add objectives
        if "optimal_pce" in optimization_results:
            data_dict["optimal_pce"] = [optimization_results["optimal_pce"]]
        if "optimal_etr" in optimization_results:
            data_dict["optimal_etr"] = [optimization_results["optimal_etr"]]

        # Add other metrics
        for key, value in optimization_results.items():
            if key not in [
                "optimal_params",
                "optimal_pce",
                "optimal_etr",
                "transmission_func",
                "success",
                "message",
            ]:
                if not isinstance(value, (dict, list, np.ndarray)):
                    data_dict[key] = [value]

        # Add metadata
        for key, value in metadata.items():
            data_dict[f"meta_{key}"] = [str(value)]

        df = pd.DataFrame(data_dict)
        df.to_csv(filepath, index=False)

        logger.info(f"Spectral optimization data saved to {filepath}")
        return filepath

    def save_agrivoltaic_results(
        self,
        pce: float,
        etr: float,
        spectral_data: Dict[str, np.ndarray],
        filename_prefix: str = "agrivoltaic_results",
        **metadata,
    ) -> str:
        """
        Save agrivoltaic coupling results to CSV.

        Parameters:
        -----------
        pce : float
            Power conversion efficiency
        etr : float
            Electron transport rate
        spectral_data : dict
            Spectral data (wavelengths, transmission, etc.)
        filename_prefix : str
            Prefix for the output filename
        **metadata : dict
            Additional metadata to include

        Returns:
        --------
        str
            Path to the saved CSV file
        """
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filepath = os.path.join(self.output_dir, f"{filename_prefix}_{timestamp}.csv")

        # Determine the number of data points from the spectral data
        n_points = 0
        for _, value in spectral_data.items():
            if isinstance(value, np.ndarray):
                n_points = max(n_points, len(value))

        # Create DataFrame
        data_dict = {"pce": [pce], "etr": [etr]}

        # Add spectral data as columns
        for key, value in spectral_data.items():
            if isinstance(value, np.ndarray):
                if len(value) == n_points:
                    data_dict[key] = value
                else:
                    # If it's a single value, repeat for all rows
                    data_dict[key] = [value[0]] * n_points
            else:
                data_dict[key] = [value] * n_points

        df = pd.DataFrame(data_dict)

        # Add metadata as additional rows at the end
        if metadata:
            metadata_row = {"pce": "METADATA", "etr": str(metadata)}
            metadata_df = pd.DataFrame([metadata_row])
            df = pd.concat([df, metadata_df], ignore_index=True)

        df.to_csv(filepath, index=False)
        logger.info(f"Agrivoltaic results saved to {filepath}")
        return filepath

    def save_biodegradability_analysis(
        self,
        analysis_results: Dict[str, Any],
        filename_prefix: str = "biodegradability_analysis",
        **metadata,
    ) -> str:
        """
        Save biodegradability analysis results to CSV.

        Parameters:
        -----------
        analysis_results : dict
            Results from biodegradability analysis
        filename_prefix : str
            Prefix for the output filename
        **metadata : dict
            Additional metadata to include

        Returns:
        --------
        str
            Path to the saved CSV file
        """
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filepath = os.path.join(self.output_dir, f"{filename_prefix}_{timestamp}.csv")

        # Create DataFrame from analysis results
        data_dict = {}

        # Add all scalar values from analysis results
        for key, value in analysis_results.items():
            if isinstance(value, (int, float, str, bool)):
                data_dict[key] = [value]
            elif isinstance(value, (list, np.ndarray)) and np.isscalar(value[0]):
                data_dict[key] = [str(value)]
            else:
                data_dict[key] = [str(value)]

        # Add metadata
        for key, value in metadata.items():
            data_dict[f"meta_{key}"] = [str(value)]

        df = pd.DataFrame(data_dict)
        df.to_csv(filepath, index=False)

        logger.info(f"Biodegradability analysis saved to {filepath}")
        return filepath

    def save_lca_results(
        self,
        lca_results: Dict[str, Any],
        filename_prefix: str = "lca_analysis",
        **metadata,
    ) -> str:
        """
        Save Life Cycle Assessment results to CSV.

        Parameters:
        -----------
        lca_results : dict
            Results from LCA analysis
        filename_prefix : str
            Prefix for the output filename
        **metadata : dict
            Additional metadata to include

        Returns:
        --------
        str
            Path to the saved CSV file
        """
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filepath = os.path.join(self.output_dir, f"{filename_prefix}_{timestamp}.csv")

        # Flatten nested LCA results dictionary
        def flatten_dict(d, parent_key="", sep="_"):
            items = []
            for k, v in d.items():
                new_key = f"{parent_key}{sep}{k}" if parent_key else k
                if isinstance(v, dict):
                    items.extend(flatten_dict(v, new_key, sep=sep).items())
                else:
                    items.append((new_key, v))
            return dict(items)

        flat_results = flatten_dict(lca_results)

        # Create DataFrame
        data_dict = {}
        for key, value in flat_results.items():
            if isinstance(value, (int, float, str, bool)):
                data_dict[key] = [value]
            else:
                data_dict[key] = [str(value)]

        # Add metadata
        for key, value in metadata.items():
            data_dict[f"meta_{key}"] = [str(value)]

        df = pd.DataFrame(data_dict)
        df.to_csv(filepath, index=False)

        logger.info(f"LCA results saved to {filepath}")
        return filepath
