"""Minimal logging configuration for the quantum simulations framework."""
import logging


def get_logger(name: str) -> logging.Logger:
    """Return a logger with the given name, using the root logger's handlers."""
    return logging.getLogger(name)
