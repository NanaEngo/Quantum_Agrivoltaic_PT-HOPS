import sys
from pathlib import Path

import numpy as np

# Add the parent directory to sys.path to allow importing from the framework
sys.path.insert(0, str(Path(__file__).parent.parent))

import pytest
from core.constants import DEFAULT_TEMPERATURE, FMO_COUPLINGS, FMO_SITE_ENERGIES_7, KB_CM_K
from core.hamiltonian_factory import create_fmo_hamiltonian
from core.hops_simulator import HopsSimulator


def test_physical_constants():
    """Verify that basic physical constants are defined and positive."""
    assert DEFAULT_TEMPERATURE > 0
    assert KB_CM_K > 0
    assert len(FMO_SITE_ENERGIES_7) > 0
    assert isinstance(FMO_COUPLINGS, dict)


def test_hamiltonian_factory():
    """Verify that the Hamiltonian factory generates valid FMO matrices."""
    H, energies = create_fmo_hamiltonian(include_reaction_center=False)
    n_sites = H.shape[0]
    assert H.shape == (n_sites, n_sites)
    assert np.allclose(np.diag(H), energies)
    # Symmetry check
    assert np.allclose(H, H.T)

    # Test 8-site (RC) variant
    H8, e8 = create_fmo_hamiltonian(include_reaction_center=True)
    assert H8.shape == (8, 8)


def test_hops_simulator_initialization():
    """Test HopsSimulator initialization and fallback logic."""
    H, _ = create_fmo_hamiltonian(include_reaction_center=False)

    # Initialize without MesoHOPS (forced fallback)
    temp = 300.0
    simulator = HopsSimulator(H, temperature=temp, use_mesohops=False)

    assert simulator.temperature == temp
    assert not simulator.use_mesohops


def test_hops_simulator_simulation_stub():
    """Test a basic simulation call (even if stubbed/failed in environment)."""
    H, _ = create_fmo_hamiltonian(include_reaction_center=False)
    simulator = HopsSimulator(H, use_mesohops=False)
    n_sites = H.shape[0]
    time_points = np.linspace(0, 100, 10)
    initial_state = np.zeros(n_sites)
    initial_state[0] = 1.0

    results = simulator.simulate_dynamics(time_points, initial_state)
    assert isinstance(results, dict)
    assert "t_axis" in results
    assert "populations" in results


if __name__ == "__main__":
    pytest.main([__file__])
