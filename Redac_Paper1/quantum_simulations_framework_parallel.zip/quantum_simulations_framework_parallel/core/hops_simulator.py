"""
HopsSimulator: Unified quantum dynamics simulator with MesoHOPS integration.

This module provides the HopsSimulator class which uses MesoHOPS as the default
simulation engine with automatic fallback to QuantumDynamicsSimulator.
"""

import sys
from typing import Any, Dict, Optional

import numpy as np
import scipy.sparse as sp
from numpy.typing import NDArray
import multiprocessing
try:
    from joblib import Parallel, delayed
    HAS_JOBLIB = True
except ImportError:
    HAS_JOBLIB = False

try:
    from tqdm.auto import tqdm
    HAS_TQDM = True
except ImportError:
    HAS_TQDM = False

# Import MesoHOPS modules
try:
    from mesohops.basis.hops_basis import HopsBasis
    from mesohops.basis.hops_system import HopsSystem
    from mesohops.trajectory.hops_trajectory import HopsTrajectory
    try:
        from mesohops.eom.hops_eom import HopsEOM
    except ImportError:
        HopsEOM = None

    MESOHOPS_AVAILABLE = True
except ImportError:
    MESOHOPS_AVAILABLE = False
    HopsSystem = None
    HopsBasis = None
    HopsTrajectory = None
    HopsEOM = None

# Import our custom PT-HOPS and SBD Extensions (absolute import)
try:
    from extensions.mesohops_adapters import PT_HopsNoise, SBD_HopsTrajectory
except ImportError:
    try:
        from ..extensions.mesohops_adapters import PT_HopsNoise, SBD_HopsTrajectory
    except ImportError:
        SBD_HopsTrajectory = None
        PT_HopsNoise = None

# Import fallback simulators from models package (absolute import)
try:
    from models import QuantumDynamicsSimulator, SimpleQuantumDynamicsSimulator
except ImportError:
    try:
        from ..models import QuantumDynamicsSimulator, SimpleQuantumDynamicsSimulator
    except ImportError:
        QuantumDynamicsSimulator = None
        SimpleQuantumDynamicsSimulator = None

try:
    from core.constants import (
        DEFAULT_DRUDE_CUTOFF,
        DEFAULT_HUANG_RHYS_FACTORS,
        DEFAULT_MAX_HIERARCHY,
        DEFAULT_N_MATSUBARA,
        DEFAULT_REORGANIZATION_ENERGY,
        DEFAULT_TEMPERATURE,
        DEFAULT_VIBRONIC_DAMPING,
        DEFAULT_VIBRONIC_FREQUENCIES,
        PULSE_CENTRAL_FREQ,
        PULSE_FWHM,
        PULSE_RELATIVE_DELAY,
        PULSE_TYPE,
        PULSE_AMPLITUDE,
    )
except ImportError:
    from .constants import (
        DEFAULT_DRUDE_CUTOFF,
        DEFAULT_HUANG_RHYS_FACTORS,
        DEFAULT_MAX_HIERARCHY,
        DEFAULT_N_MATSUBARA,
        DEFAULT_REORGANIZATION_ENERGY,
        DEFAULT_TEMPERATURE,
        DEFAULT_VIBRONIC_DAMPING,
        DEFAULT_VIBRONIC_FREQUENCIES,
        PULSE_CENTRAL_FREQ,
        PULSE_FWHM,
        PULSE_RELATIVE_DELAY,
        PULSE_TYPE,
        PULSE_AMPLITUDE,
    )

try:
    from utils.logging_config import get_logger
except ImportError:
    from ..utils.logging_config import get_logger


def get_mesohops_version() -> Optional[str]:
    """Return the installed MesoHOPS version or None if not available."""
    try:
        import mesohops

        return getattr(mesohops, "__version__", None)
    except (ImportError, ModuleNotFoundError):
        return None


logger = get_logger(__name__)


class HopsSimulator:
    """
    Unified simulator that uses MesoHOPS by default with fallback.

    This class provides a consistent interface for quantum dynamics simulations,
    automatically using MesoHOPS when available and falling back to the custom
    QuantumDynamicsSimulator when needed.

    Parameters
    ----------
    hamiltonian : NDArray[np.float64]
        System Hamiltonian matrix in cm⁻¹. Must be square and Hermitian.
    temperature : float, optional
        Temperature in Kelvin (default: 295.0)
    use_mesohops : bool, optional
        Whether to use MesoHOPS if available (default: True)
    max_hierarchy : int, optional
        Maximum hierarchy level for MesoHOPS (default: 10)
    **kwargs : dict
        Additional arguments passed to underlying simulator

    Notes
    -----
    Energy shift: the Hamiltonian is internally zero-shifted by subtracting the
    mean diagonal energy before passing it to MesoHOPS:

        H_shifted = H - mean(diag(H)) · I

    For the FMO complex this removes ~12 400 cm⁻¹ from all site energies,
    preventing rapid oscillations exp(-iHt/ℏ) that cause numerical overflow in
    the integrator. All physical observables (populations, coherences, QFI) are
    invariant to this uniform energy shift.

    Attributes
    ----------
    hamiltonian : NDArray[np.float64]
        The system Hamiltonian (unshifted, as provided by the caller)
    temperature : float
        Simulation temperature
    use_mesohops : bool
        Whether MesoHOPS is being used
    system : Optional[HopsSystem]
        MesoHOPS system object (if initialized)
    fallback_sim : Optional[QuantumDynamicsSimulator]
        Fallback simulator (if initialized)

    Examples
    --------
    >>> import numpy as np
    >>> from core.hops_simulator import HopsSimulator
    >>> hamiltonian = np.array([[1, 0.5], [0.5, 1]])
    >>> simulator = HopsSimulator(hamiltonian, temperature=DEFAULT_TEMPERATURE)
    >>> time_points = np.linspace(0, 100, 100)
    >>> results = simulator.simulate_dynamics(time_points)
    """

    def __init__(
        self,
        hamiltonian: NDArray[np.float64],
        temperature: float = DEFAULT_TEMPERATURE,
        use_mesohops: bool = True,
        max_hierarchy: int = DEFAULT_MAX_HIERARCHY,
        k_matsubara: int = DEFAULT_N_MATSUBARA,
        **kwargs: Any,
    ):
        """Initialize the simulator."""
        self.hamiltonian = hamiltonian
        self.temperature = temperature
        self.max_hierarchy = max_hierarchy
        self.k_matsubara = k_matsubara
        self.use_mesohops = MESOHOPS_AVAILABLE and use_mesohops
        self.use_pt_hops = kwargs.pop("use_pt_hops", False)
        self.use_sbd = kwargs.pop("use_sbd", False)
        self.sbd_bundles_per_site = kwargs.pop("sbd_bundles_per_site", 2)
        self.system = None
        self.fallback_sim: Optional[Any] = None

        # D-4 FIX: validate Hermiticity before any simulation work.
        # A non-Hermitian Hamiltonian produces complex eigenvalues and unphysical
        # dynamics that are hard to diagnose downstream. Catch it here.
        H = np.asarray(hamiltonian)
        if H.ndim == 2 and H.shape[0] == H.shape[1]:
            max_asymmetry = np.max(np.abs(H - H.conj().T))
            if max_asymmetry > 1e-8:
                raise ValueError(
                    f"Hamiltonian is not Hermitian: max|H - H†| = {max_asymmetry:.2e}. "
                    "Check units and construction (should be in cm⁻¹, symmetric couplings)."
                )

        logger.debug(
            f"Initializing HopsSimulator (MesoHOPS available: {MESOHOPS_AVAILABLE}, "
            f"use_mesohops: {use_mesohops})"
        )

        if self.use_mesohops:
            self._init_mesohops(**kwargs)

        # Always initialize fallback so it is available if MesoHOPS fails mid-run.
        # _init_mesohops may have already set fallback_sim (on init failure path);
        # skip re-initialization in that case.
        if self.fallback_sim is None:
            self._init_fallback(**kwargs)

    @staticmethod
    def _alpha_noise1(t_axis: NDArray[np.float64], g: complex, w: complex) -> NDArray[np.complex128]:
        """Single-mode bath correlation function: alpha(t) = g * exp(-w*t)."""
        return g * np.exp(-w * t_axis)

    @staticmethod
    def _bcf_dl_to_exp_pairs(lam: float, gamma: float, T: float, k: int) -> list:
        """
        Robustly convert Drude-Lorentz bath parameters to exponential pairs (g, w).
        Probes the installed MesoHOPS API signature to handle version differences.
        """
        import inspect
        from mesohops.util.bath_corr_functions import bcf_convert_dl_to_exp
        
        try:
            from mesohops.util.bath_corr_functions import bcf_convert_dl_to_exp_with_Matsubara
            # Priority 1: Modern MesoHOPS (v1.6+) with explicit Matsubara function
            dl_modes = bcf_convert_dl_to_exp_with_Matsubara(lam, gamma, T, k)
        except (ImportError, AttributeError):
            # Priority 2: Probe signature of bcf_convert_dl_to_exp
            sig = inspect.signature(bcf_convert_dl_to_exp)
            params = sig.parameters
            
            if 'n_matsubara' in params:
                # Keyword form (~v1.5)
                dl_modes = bcf_convert_dl_to_exp(lam, gamma, T, n_matsubara=k)
            elif len(params) >= 4:
                # Positional form (~v1.4)
                dl_modes = bcf_convert_dl_to_exp(lam, gamma, T, k)
            else:
                # 3-arg form (<=v1.3) — low-temp corrections not available
                dl_modes = bcf_convert_dl_to_exp(lam, gamma, T)
        
        # Validate output format: must be flat list [g0, w0, g1, w1, ...]
        if not isinstance(dl_modes, (list, np.ndarray)) or len(dl_modes) % 2 != 0:
            raise RuntimeError(f"MesoHOPS bath conversion returned unexpected format: {type(dl_modes)}")
            
        return [[dl_modes[i], dl_modes[i+1]] for i in range(0, len(dl_modes), 2)]

    def _init_mesohops(self, **kwargs: Any) -> None:
        """Initialize MesoHOPS simulator with proper system parameters."""
        try:
            # Prepare system parameters for MesoHOPS - correct API format
            n_sites = self.hamiltonian.shape[0]

            # Get bath parameters from kwargs or use defaults
            lambda_reorg = kwargs.get("reorganization_energy", DEFAULT_REORGANIZATION_ENERGY)
            gamma_cutoff = kwargs.get("drude_cutoff", DEFAULT_DRUDE_CUTOFF)

            # Define system-bath coupling operators (Lindblad operators)
            # MesoHOPS requires sparse matrices for efficiency and compatibility
            L_ops = []
            for i in range(n_sites):
                L_op = np.zeros((n_sites, n_sites), dtype=complex)
                L_op[i, i] = 1.0  # Diagonal operator for site i
                L_ops.append(sp.csc_matrix(L_op))

            # Shift Hamiltonian to center energies around 0.
            E_mean = np.mean(np.diag(self.hamiltonian).real)
            H_shifted = self.hamiltonian - E_mean * np.eye(n_sites, dtype=complex)

            # Build GW_SYSBATH as a flat list of (g, w) tuples — one entry per mode per site.
            gw_sysbath = []
            l_hier_flat = []
            l_noise_flat = []
            param_noise_flat = []

            # 1. Drude-Lorentz modes (one per site)
            # FIX H-6: Use version-agnostic helper to build dl_pairs
            dl_pairs = self._bcf_dl_to_exp_pairs(
                lambda_reorg, gamma_cutoff, self.temperature, self.k_matsubara
            )

            for i in range(n_sites):
                for g, w in dl_pairs:
                    gw_sysbath.append([g, w])
                    l_hier_flat.append(L_ops[i])
                    l_noise_flat.append(L_ops[i])
                    param_noise_flat.append([g, w])

            # 2. Vibronic modes (one per mode per site)
            vib_freqs = kwargs.get("vibronic_frequencies", DEFAULT_VIBRONIC_FREQUENCIES)
            vib_hr = kwargs.get("huang_rhys_factors", DEFAULT_HUANG_RHYS_FACTORS)
            vib_damping_raw = kwargs.get("vibronic_damping", DEFAULT_VIBRONIC_DAMPING)
            
            if np.isscalar(vib_damping_raw):
                vib_damping = np.full(len(vib_freqs), float(vib_damping_raw))
            else:
                vib_damping = np.asarray(vib_damping_raw, dtype=float)

            # Attempt to load the underdamped BCF converter; fall back to
            # single-mode Lorentzian representation if unavailable.
            _ud_bcf = None
            for _fname in ('bcf_convert_sdl_to_exp', 'bcf_convert_dl_ud_to_exp'):
                try:
                    import importlib
                    _mod = importlib.import_module('mesohops.util.bath_corr_functions')
                    _ud_bcf = getattr(_mod, _fname, None)
                    if _ud_bcf is not None:
                        break
                except ImportError:
                    pass

            n_vib_added = 0
            for freq, hr, damp in zip(vib_freqs, vib_hr, vib_damping, strict=False):
                lambda_vib = hr * freq
                if _ud_bcf is not None:
                    try:
                        ud_modes = _ud_bcf(lambda_vib, damp, freq, self.temperature)
                        ud_pairs = [[ud_modes[i], ud_modes[i+1]] for i in range(0, len(ud_modes), 2)]
                    except Exception as _e:
                        logger.warning(f"ud_bcf failed for freq={freq}: {_e} — using single-mode fallback")
                        ud_pairs = [[lambda_vib, freq + 1j * damp]]
                else:
                    # Single-mode Lorentzian: g=λ_vib, w=ω_k + iγ_k
                    ud_pairs = [[lambda_vib, freq + 1j * damp]]
                for g, w in ud_pairs:
                    for i in range(n_sites):
                        gw_sysbath.append([g, w])
                        l_hier_flat.append(L_ops[i])
                        l_noise_flat.append(L_ops[i])
                        param_noise_flat.append([g, w])
                n_vib_added += len(ud_pairs)

            # 3. System parameters dictionary — MesoHOPS format
            self.system_param = {
                "HAMILTONIAN": H_shifted,
                "GW_SYSBATH": gw_sysbath,
                "L_HIER": l_hier_flat,
                "L_NOISE1": l_noise_flat,
                "ALPHA_NOISE1": self._alpha_noise1,
                "PARAM_NOISE1": param_noise_flat,
                "PULSE_PARAMS": {
                    "type": kwargs.get("pulse_type", PULSE_TYPE),
                    "fwhm": kwargs.get("pulse_fwhm", PULSE_FWHM),
                    "delay": kwargs.get("pulse_delay", PULSE_RELATIVE_DELAY),
                    "center_freq": kwargs.get("pulse_center_freq", PULSE_CENTRAL_FREQ),
                    "amplitude": kwargs.get("pulse_amplitude", 0.05),
                }
            }
            logger.info(
                f"MesoHOPS system_param built: {len(gw_sysbath)} hierarchy modes "
                f"({len(dl_pairs)} DL + {n_vib_added} vibronic pairs × {n_sites} sites)"
            )
        except Exception as e:
            logger.warning(f"Failed to initialize MesoHOPS: {e}")
            logger.info("Falling back to fallback chain...")
            self.use_mesohops = False
            self._init_fallback(**kwargs)

    def _init_fallback(self, **kwargs: Any) -> None:
        """Initialize fallback simulator with proper priority."""
        # Priority 1: Full QuantumDynamicsSimulator (requires MesoHOPS but has more robust init)
        if QuantumDynamicsSimulator is not None:
            try:
                # Filter kwargs to only pass parameters that QuantumDynamicsSimulator accepts
                qds_kwargs = {}
                valid_params = {
                    "temperature",
                    "lambda_reorg",
                    "gamma_dl",
                    "k_matsubara",
                    "max_hier",
                    "n_traj",
                    "vibronic_modes",
                }

                for key, value in kwargs.items():
                    if key in valid_params:
                        qds_kwargs[key] = value

                # Use default values if not provided
                qds_kwargs.setdefault("temperature", self.temperature)
                qds_kwargs.setdefault(
                    "lambda_reorg",
                    kwargs.get("reorganization_energy", DEFAULT_REORGANIZATION_ENERGY),
                )
                qds_kwargs.setdefault("gamma_dl", kwargs.get("drude_cutoff", DEFAULT_DRUDE_CUTOFF))
                qds_kwargs.setdefault("max_hier", self.max_hierarchy)
                qds_kwargs.setdefault("k_matsubara", self.k_matsubara)
                qds_kwargs.setdefault("n_traj", 10)

                self.fallback_sim = QuantumDynamicsSimulator(self.hamiltonian, **qds_kwargs)
                logger.info("QuantumDynamicsSimulator (HOPS-based) initialized as fallback")
                return
            except Exception as e:
                logger.warning(f"Failed to initialize QuantumDynamicsSimulator fallback: {e}")

        # Priority 2: SimpleQuantumDynamicsSimulator (no MesoHOPS required, but less accurate)
        if SimpleQuantumDynamicsSimulator is not None:
            try:
                self.fallback_sim = SimpleQuantumDynamicsSimulator(
                    self.hamiltonian, temperature=self.temperature
                )
                logger.info("SimpleQuantumDynamicsSimulator (Schrödinger-based) initialized as fallback")
                return
            except Exception as e:
                logger.error(f"Failed to initialize SimpleQuantumDynamicsSimulator fallback: {e}")

        # If both fail, log error
        logger.error("Failed to initialize any fallback simulator")
        self.fallback_sim = None

    def simulate_dynamics(
        self,
        time_points: NDArray[np.float64],
        initial_state: Optional[NDArray[np.float64]] = None,
        **kwargs: Any,
    ) -> Dict[str, Any]:
        """
        Simulate quantum dynamics.

        Uses MesoHOPS if available, otherwise falls back to custom simulator.

        Parameters
        ----------
        time_points : NDArray[np.float64]
            Array of time points for simulation
        initial_state : Optional[NDArray[np.float64]]
            Initial quantum state (default: None)
        **kwargs : dict
            Additional simulation parameters

        Returns
        -------
        Dict[str, Any]
            Simulation results containing populations, coherences, and other metrics

        Raises
        ------
        RuntimeError
            If no simulator is available
        """
        logger.info(f"Starting dynamics simulation for {len(time_points)} time points")

        if self.use_mesohops and hasattr(self, "system_param") and self.system_param is not None:
            try:
                logger.debug("Attempting MesoHOPS simulation")
                return self._simulate_with_mesohops(time_points, initial_state, **kwargs)
            except (RuntimeError, ModuleNotFoundError) as e:
                logger.error(f"MesoHOPS simulation failed mid-run, falling back to SimpleQuantumDynamicsSimulator: {e}")
                logger.info("Falling back to custom simulator...")

        # Fallback to custom simulator
        if self.fallback_sim is not None:
            logger.warning("Using fallback simulator. Results will not show L-dependence.")
            # Remove aggressive filtering so fallback receives all physics params
            fallback_kwargs = dict(kwargs)
            # Use keyword args to avoid arg-order mismatch between fallback implementations
            return self.fallback_sim.simulate_dynamics(
                time_points=time_points, initial_state=initial_state, **fallback_kwargs
            )
        else:
            raise RuntimeError("No simulator available")

    def _simulate_with_mesohops(
        self,
        time_points: NDArray[np.float64],
        initial_state: Optional[NDArray[np.float64]],
        **kwargs: Any,
    ) -> Dict[str, Any]:
        """
        Internal method to run MesoHOPS simulation with proper quantum dynamics.

        Mathematical Framework:
        Uses the Hierarchy of Pure States (HOPS) method to solve the
        stochastic Schrödinger equation for non-Markovian open quantum systems:

        |ψ(t)⟩ = |ψ(0)⟩ + ∫₀ᵗ dt' [Ĥ_eff(t') + noise terms] |ψ(t')⟩

        where Ĥ_eff includes the system Hamiltonian and system-bath interactions.
        """
        # Import required MesoHOPS classes
        if HopsTrajectory is None:
            raise RuntimeError("MesoHOPS not available for simulation")

        try:
            # Get simulation parameters
            max_hierarchy = kwargs.get("max_hierarchy", self.max_hierarchy)
            k_matsubara = kwargs.get("k_matsubara", self.k_matsubara)

            # Set up hierarchy parameters — L is the truncation depth.
            # TERMINATOR=True applies the Markovian terminator at the boundary,
            # which reduces memory by ~50% with negligible accuracy loss.
            # STATIC_BASIS with triangular filter cuts the active hierarchy
            # from O(modes^L) to O(modes*L) — essential for 77-mode systems.
            # STATIC_FILTERS "Triangular" expects params = [boolean_by_mode, kmax_2]
            # boolean_by_mode: list of bools, length n_hmodes (which modes to filter)
            # kmax_2: int, max individual mode depth (set equal to MAXHIER = no extra cut)
            n_hmodes = len(self.system_param["GW_SYSBATH"])
            hierarchy_param = {
                "MAXHIER": max_hierarchy,
                "TERMINATOR": True,
                "STATIC_FILTERS": [["Triangular", [[True] * n_hmodes, max_hierarchy]]],
            }

            # Set up EOM parameters - use NORMALIZED NONLINEAR for better numerical stability
            eom_param = {
                "EQUATION_OF_MOTION": "NORMALIZED NONLINEAR",
                "TIME_DEPENDENCE": False,
            }

            # Set up noise parameters based on test examples
            t_max = float(np.max(time_points)) if len(time_points) > 0 else 500.0
            # Use explicit dt if provided to handle arbitrary time grids safely
            dt_save = kwargs.get("dt", float(time_points[1] - time_points[0]) if len(time_points) > 1 else 0.5)

            noise_param = {
                "SEED": kwargs.get("seed", 42),
                "MODEL": "FFT_FILTER",
                "TLEN": t_max + 50.0,  # 50 fs buffer is sufficient for FFT_FILTER stability
                # TAU must equal tau * integrator_step (RK uses integrator_step=0.5).
                # propagate(t_max, dt_save) passes tau=dt_save, so the internal
                # sub-step is dt_save * 0.5. TAU must divide that sub-step evenly.
                "TAU": dt_save * 0.5,
            }

            # Set up integrator parameters based on test examples
            integrator_param = {
                "INTEGRATOR": "RUNGE_KUTTA",
                "EARLY_ADAPTIVE_INTEGRATOR": "INCH_WORM",
                "EARLY_INTEGRATOR_STEPS": 5,
                "INCHWORM_CAP": 5,
                "STATIC_BASIS": None,
            }

            # Select Trajectory Engine
            TrajectoryClass = HopsTrajectory
            traj_kwargs = {
                "system_param": self.system_param,
                "eom_param": eom_param,
                "noise_param": noise_param,
                "hierarchy_param": hierarchy_param,
                "integration_param": integrator_param,
            }

            if self.use_sbd and SBD_HopsTrajectory is not None:
                TrajectoryClass = SBD_HopsTrajectory
                traj_kwargs["n_bundles_per_site"] = kwargs.get("sbd_bundles_per_site", self.sbd_bundles_per_site)
                logger.info("Engaging SBD_HopsTrajectory for compressed environmental simulation.")
            elif self.use_pt_hops and PT_HopsNoise is not None:
                logger.info("Engaging PT_HopsNoise for Process Tensor dynamics.")
                # We will handle PT-HOPS by overriding the noise component after trajectory init
                pass

            # ── Run ensemble of trajectories (Parallelized) ─────────────────────
            n_traj = kwargs.get("n_traj", 1)
            cpu_count = multiprocessing.cpu_count()
            n_jobs = max(1, int(cpu_count * 2 / 3)) if n_traj > 1 else 1

            # Determine seeds
            seeds = kwargs.get("seeds", list(range(n_traj)))

            def _run_single_traj(seed):
                try:
                    # Deep copy of params to avoid process collisions
                    local_traj_kwargs = dict(traj_kwargs)
                    local_traj_kwargs["noise_param"] = dict(traj_kwargs["noise_param"])
                    local_traj_kwargs["noise_param"]["SEED"] = seed
                    
                    trajectory = TrajectoryClass(**local_traj_kwargs)
                    
                    if self.use_pt_hops and PT_HopsNoise is not None:
                        pt_noise = PT_HopsNoise(local_traj_kwargs["noise_param"], self.system_param["PARAM_NOISE1"])
                        if hasattr(trajectory, "noise"):
                            trajectory.noise = pt_noise
                        pt_noise._prepare_noise(self.system_param["L_NOISE1"], time_points=time_points)
                    
                    trajectory.initialize(initial_state.copy())
                    trajectory.propagate(t_max, dt_save)
                    
                    # Return essential data
                    return {
                        "psi_traj": np.array(trajectory.storage.data["psi_traj"]),
                        "t_axis": np.array(trajectory.storage.data["t_axis"]),
                        "pop_site": np.array(trajectory.storage.data.get("pop_site", []))
                    }
                except Exception as e:
                    logger.error(f"Parallel trajectory {seed} failed: {e}")
                    return None

            if HAS_JOBLIB and n_jobs > 1:
                logger.info(f"Running ensemble of {n_traj} trajectories on {n_jobs} cores...")
                
                # Setup tqdm progress bar
                iterable = seeds
                if HAS_TQDM and kwargs.get("show_progress", True):
                    desc = kwargs.get("desc", "Trajectories")
                    iterable = tqdm(seeds, desc=desc, unit="traj", leave=False)
                
                traj_results = Parallel(n_jobs=n_jobs)(
                    delayed(_run_single_traj)(s) for s in iterable
                )
            else:
                traj_results = [_run_single_traj(s) for s in seeds]

            # Filter failed trajectories
            traj_results = [r for r in traj_results if r is not None]
            if not traj_results:
                raise RuntimeError("All parallel trajectories failed.")

            # Ensemble averaging
            t_axis = traj_results[0]["t_axis"]
            n_times = len(t_axis)
            n_sites = self.hamiltonian.shape[0]
            n_valid = len(traj_results)
            
            # Construct averaged rho(t)
            # We use the physical subspace (first n_sites)
            density_matrices = []
            populations = np.zeros((n_times, n_sites))
            coherences = np.zeros(n_times)
            
            for i in range(n_times):
                rho = np.zeros((n_sites, n_sites), dtype=complex)
                for res in traj_results:
                    psi = res["psi_traj"][i, :n_sites]
                    rho += np.outer(psi, np.conj(psi))
                rho /= n_valid
                
                # Trace normalization
                tr = np.trace(rho).real
                if tr > 1e-10:
                    rho /= tr
                
                density_matrices.append(rho)
                populations[i, :] = np.real(np.diag(rho))
                coherences[i] = float(np.sum(np.abs(rho)) - np.sum(np.abs(np.diag(rho))))

            # Calculate other metrics (QFI, IPR, Entropy)
            qfi_values = np.zeros(n_times)
            entropy_values = np.zeros(n_times)
            ipr_values = np.zeros(n_times)

            for i in range(n_times):
                rho = density_matrices[i]
                entropy_values[i] = self._calculate_von_neumann_entropy(rho)
                try:
                    qfi_values[i] = self._calculate_qfi(rho, self.hamiltonian)
                except (np.linalg.LinAlgError, ValueError):
                    qfi_values[i] = 0.0
                diag_sq = np.sum(np.real(np.diag(rho)) ** 2)
                ipr_values[i] = 1.0 / diag_sq if diag_sq > 1e-12 else 1.0

            logger.info(f"Ensemble averaged over {n_valid} trajectories completed.")

            return {
                "t_axis": t_axis,
                "populations": populations,
                "coherences": coherences,
                "qfi": qfi_values,
                "entropy": entropy_values,
                "ipr": ipr_values,
                "simulator": "MesoHOPS-Parallel",
                "n_traj_used": n_valid,
                "max_hierarchy_used": kwargs.get("max_hierarchy", self.max_hierarchy),
            }

        except (
            RuntimeError,
            AttributeError,
            ValueError,
            TypeError,
            OSError,
            np.linalg.LinAlgError,
        ) as e:
            import traceback

            traceback.print_exc()
            logger.error(f"MesoHOPS simulation failed: {e}")
            raise RuntimeError(f"MesoHOPS simulation failed: {e}") from e

    def _calculate_von_neumann_entropy(self, rho: NDArray[np.float64]) -> float:
        """Calculate the von Neumann entropy: -Tr[rho * log(rho)]."""
        # Get eigenvalues of the density matrix
        eigenvals = np.linalg.eigvals(rho)
        # Take real part and ensure non-negative
        eigenvals = np.real(eigenvals)
        eigenvals = np.clip(eigenvals, 1e-12, None)
        # Calculate entropy: -Σ λᵢ log(λᵢ)
        entropy = -np.sum(eigenvals * np.log(eigenvals))
        return float(entropy)

    def _calculate_qfi(self, rho: NDArray[np.float64], H: NDArray[np.float64]) -> float:
        """
        Calculate the Quantum Fisher Information for parameter estimation.

        QFI = 2 * Σᵢ Σⱼ (λᵢ - λⱼ)² / (λᵢ + λⱼ) * |⟨i|H|j⟩|²
        where λᵢ are eigenvalues and |i⟩ are eigenvectors of rho.
        """
        try:
            eigenvals, eigenvecs = np.linalg.eigh(rho)
            eigenvals = np.real(eigenvals)

            # Calculate QFI
            qfi = 0.0
            n = len(eigenvals)
            for i in range(n):
                for j in range(n):
                    denom = eigenvals[i] + eigenvals[j]
                    if denom > 1e-12:
                        Hij = np.abs(np.vdot(eigenvecs[:, i], H @ eigenvecs[:, j])) ** 2
                        qfi += 2.0 * (eigenvals[i] - eigenvals[j]) ** 2 / denom * Hij

            return float(qfi)
        except (np.linalg.LinAlgError, ValueError):
            return 0.0

    def create_basis(self) -> Optional[HopsBasis]:
        """
        Create MesoHOPS basis for the Hamiltonian.

        Returns
        -------
        Optional[HopsBasis]
            MesoHOPS basis object or None if not available
        """
        if not MESOHOPS_AVAILABLE or HopsBasis is None:
            logger.warning("MesoHOPS not available for basis creation")
            return None

        try:
            system_dict = {
                "hamiltonian": self.hamiltonian,
                "temperature": self.temperature,
                "n_site": self.hamiltonian.shape[0],
                "n_exciton": 1,
            }
            basis = HopsBasis(system_dict, self.max_hierarchy)
            logger.debug("MesoHOPS basis created successfully")
            return basis
        except (RuntimeError, ValueError, TypeError) as e:
            logger.error(f"Failed to create MesoHOPS basis: {e}")
            return None

    def create_trajectory(self, basis: HopsBasis) -> Optional[HopsTrajectory]:
        """
        Create MesoHOPS trajectory for quantum dynamics.

        Parameters
        ----------
        basis : HopsBasis
            MesoHOPS basis object

        Returns
        -------
        Optional[HopsTrajectory]
            MesoHOPS trajectory object or None if not available
        """
        if not MESOHOPS_AVAILABLE or HopsTrajectory is None:
            logger.warning("MesoHOPS not available for trajectory creation")
            return None

        try:
            trajectory = HopsTrajectory(
                basis, temperature=self.temperature, max_hier=self.max_hierarchy
            )
            logger.debug("MesoHOPS trajectory created successfully")
            return trajectory
        except (RuntimeError, ValueError, TypeError) as e:
            logger.error(f"Failed to create MesoHOPS trajectory: {e}")
            return None

    @property
    def is_using_mesohops(self) -> bool:
        """Check if MesoHOPS is being used."""
        return self.use_mesohops and hasattr(self, "system_param") and self.system_param is not None

    @property
    def simulator_type(self) -> str:
        """Get the type of simulator being used."""
        if self.is_using_mesohops:
            base = "MesoHOPS"
            exts = []
            if self.use_pt_hops:
                exts.append("PT")
            if self.use_sbd:
                exts.append("SBD")
            return f"{base} ({' + '.join(exts)})" if exts else base
        elif self.fallback_sim is not None:
            return "QuantumDynamicsSimulator (fallback)"
        else:
            return "None (not initialized)"
