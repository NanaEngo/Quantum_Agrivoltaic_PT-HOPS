"""CSV data storage utilities for quantum dynamics results."""
import os
import hashlib
import yaml
from datetime import datetime
from typing import Any, Dict, Optional
import numpy as np


class CSVDataStorage:
    """Handle CSV storage of quantum dynamics simulation results."""
    
    def __init__(self, output_dir: str = "./results"):
        """
        Initialize CSV data storage.
        
        Parameters
        ----------
        output_dir : str
            Directory to save CSV files
        """
        self.output_dir = output_dir
        os.makedirs(output_dir, exist_ok=True)
    
    def save_quantum_dynamics_results(
        self,
        t_axis: np.ndarray,
        populations: np.ndarray,
        coherences: np.ndarray,
        metrics: Optional[Dict[str, np.ndarray]] = None,
        filename_prefix: str = "quantum_dynamics",
        config_dict: Optional[Dict[str, Any]] = None,
    ) -> str:
        """
        Save quantum dynamics results to CSV.
        
        Parameters
        ----------
        t_axis : np.ndarray
            Time axis in fs
        populations : np.ndarray
            Population dynamics (n_times, n_sites)
        coherences : np.ndarray
            Coherence dynamics (n_times, n_sites, n_sites)
        metrics : dict, optional
            Additional metrics to save
        filename_prefix : str
            Prefix for output filename
        config_dict : dict, optional
            Configuration dictionary for hash generation
        
        Returns
        -------
        str
            Path to saved CSV file
        """
        import pandas as pd
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        
        # Generate config hash if provided
        config_hash = ""
        if config_dict is not None:
            config_str = yaml.dump(config_dict, sort_keys=True)
            config_hash = hashlib.md5(config_str.encode()).hexdigest()[:12]
            config_hash = f"_{config_hash}"
        
        filename = f"{filename_prefix}{config_hash}_{timestamp}.csv"
        filepath = os.path.join(self.output_dir, filename)
        
        # Build DataFrame
        data = {"time_fs": t_axis}
        
        # Add populations
        if populations.ndim == 2:
            n_sites = populations.shape[1]
            for i in range(n_sites):
                data[f"population_site_{i+1}"] = populations[:, i]
        
        # Add coherences (real and imaginary parts)
        if coherences.ndim == 3:
            n_sites = coherences.shape[1]
            for i in range(n_sites):
                for j in range(i+1, n_sites):
                    data[f"coherence_{i+1}_{j+1}_real"] = coherences[:, i, j].real
                    data[f"coherence_{i+1}_{j+1}_imag"] = coherences[:, i, j].imag
        
        # Add metrics
        if metrics:
            for key, value in metrics.items():
                if value is not None and len(value) == len(t_axis):
                    data[key] = value
        
        df = pd.DataFrame(data)
        df.to_csv(filepath, index=False)
        
        return filepath
