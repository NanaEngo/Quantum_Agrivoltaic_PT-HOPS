"""Factory functions for creating Hamiltonians."""
import numpy as np
from .constants import FMO_SITE_ENERGIES_7, FMO_SITE_ENERGIES_8, FMO_COUPLINGS


def create_fmo_hamiltonian(include_reaction_center: bool = False) -> tuple[np.ndarray, np.ndarray]:
    """
    Create FMO complex Hamiltonian matrix.
    
    Parameters
    ----------
    include_reaction_center : bool
        If True, use 8-site model (includes reaction center).
        If False, use 7-site model.
    
    Returns
    -------
    H : np.ndarray
        Hamiltonian matrix (n_sites x n_sites) in cm^-1
    site_energies : np.ndarray
        Site energies array (n_sites,) in cm^-1
    """
    site_energies = FMO_SITE_ENERGIES_8 if include_reaction_center else FMO_SITE_ENERGIES_7
    n_sites = len(site_energies)
    
    H = np.diag(site_energies.copy())
    
    for (i, j), coupling in FMO_COUPLINGS.items():
        if i < n_sites and j < n_sites:
            H[i, j] = coupling
            H[j, i] = coupling
    
    return H, site_energies
